import Navigation from "@/components/Navigation";
import Hero from "@/components/Hero";
import Services from "@/components/Services";
import About from "@/components/About";
import Testimonials from "@/components/Testimonials";
import Contact from "@/components/Contact";
import assgLogo from '@/assets/assg-logo.png';

const Index = () => {
  return (
    <div className="min-h-screen">
      <Navigation />
      <main>
        <Hero />
        <Services />
        <About />
        <Testimonials />
        <Contact />
      </main>
      
      {/* Footer */}
      <footer className="glass-nav border-t border-white/10 py-12">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-3 gap-8">
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center p-2">
                  <img 
                    src={assgLogo} 
                    alt="ASSG Logo" 
                    className="w-full h-full object-contain"
                  />
                </div>
                <div>
                  <div className="font-bold text-lg text-foreground">ASSG</div>
                  <div className="text-xs text-muted-foreground">Active Security Services Group</div>
                </div>
              </div>
              <p className="text-muted-foreground text-sm">
                Elite corporate security solutions for the world's most demanding enterprises.
              </p>
            </div>
            
            <div>
              <h3 className="font-bold text-foreground mb-4">Quick Contact</h3>
              <div className="space-y-2 text-sm">
                <div className="flex items-center space-x-2">
                  <svg className="w-4 h-4 text-primary" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M6.62,10.79C8.06,13.62 10.38,15.94 13.21,17.38L15.41,15.18C15.69,14.9 16.08,14.82 16.43,14.93C17.55,15.3 18.75,15.5 20,15.5A1,1 0 0,1 21,16.5V20A1,1 0 0,1 20,21A17,17 0 0,1 3,4A1,1 0 0,1 4,3H7.5A1,1 0 0,1 8.5,4C8.5,5.25 8.7,6.45 9.07,7.57C9.18,7.92 9.1,8.31 8.82,8.59L6.62,10.79Z"/>
                  </svg>
                  <a href="tel:+917086930942" className="text-muted-foreground hover:text-primary">+91 7086930942</a>
                </div>
                <div className="flex items-center space-x-2">
                  <svg className="w-4 h-4 text-primary" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M20,8L12,13L4,8V6L12,11L20,6M20,4H4C2.89,4 2,4.89 2,6V18A2,2 0 0,0 4,20H20A2,2 0 0,0 22,18V6C22,4.89 21.1,4 20,4Z"/>
                  </svg>
                  <a href="mailto:assgofficial@gmail.com" className="text-muted-foreground hover:text-primary">assgofficial@gmail.com</a>
                </div>
              </div>
            </div>
            
            <div>
              <h3 className="font-bold text-foreground mb-4">Services</h3>
              <div className="space-y-2 text-sm text-muted-foreground">
                <div>Access Control Systems</div>
                <div>Surveillance & Monitoring</div>
                <div>Executive Protection</div>
                <div>Cybersecurity Integration</div>
              </div>
            </div>
          </div>
          
          <div className="border-t border-white/10 mt-8 pt-8 text-center">
            <p className="text-muted-foreground text-sm">
              © 2024 Active Security Services Group. All rights reserved. | Premium Corporate Security Solutions
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
