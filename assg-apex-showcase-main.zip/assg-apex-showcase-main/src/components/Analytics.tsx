import { useEffect } from 'react';

// Enhanced Analytics and Performance Monitoring Component
const Analytics = () => {
  useEffect(() => {
    // Google Analytics 4 (GA4) Implementation
    const initializeGA4 = () => {
      // Add Google Analytics 4 script
      const script1 = document.createElement('script');
      script1.async = true;
      script1.src = 'https://www.googletagmanager.com/gtag/js?id=GA_MEASUREMENT_ID';
      document.head.appendChild(script1);

      const script2 = document.createElement('script');
      script2.innerHTML = `
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());
        gtag('config', 'GA_MEASUREMENT_ID', {
          page_title: document.title,
          page_location: window.location.href,
          custom_map: {'custom_parameter_1': 'security_service_type'}
        });
      `;
      document.head.appendChild(script2);
    };

    // Performance Monitoring
    const initializePerformanceMonitoring = () => {
      // Core Web Vitals tracking
      const observer = new PerformanceObserver((list) => {
        for (const entry of list.getEntries()) {
          if (entry.entryType === 'largest-contentful-paint') {
            console.log('LCP:', entry.startTime);
            // Send to analytics
            if (window.gtag) {
              window.gtag('event', 'web_vitals', {
                event_category: 'Performance',
                event_label: 'LCP',
                value: Math.round(entry.startTime)
              });
            }
          }
          
          if (entry.entryType === 'first-input') {
            const fidEntry = entry as any; // Type assertion for FID entry
            const fidValue = fidEntry.processingStart - entry.startTime;
            console.log('FID:', fidValue);
            if (window.gtag) {
              window.gtag('event', 'web_vitals', {
                event_category: 'Performance',
                event_label: 'FID',
                value: Math.round(fidValue)
              });
            }
          }
        }
      });

      try {
        observer.observe({ entryTypes: ['largest-contentful-paint', 'first-input'] });
      } catch (e) {
        console.log('Performance observer not supported');
      }

      // Cumulative Layout Shift (CLS) tracking
      let clsValue = 0;
      const clsObserver = new PerformanceObserver((list) => {
        for (const entry of list.getEntries()) {
          const layoutShiftEntry = entry as any; // Type assertion for layout shift entry
          if (!layoutShiftEntry.hadRecentInput) {
            clsValue += layoutShiftEntry.value;
          }
        }
      });

      try {
        clsObserver.observe({ entryTypes: ['layout-shift'] });
      } catch (e) {
        console.log('Layout shift observer not supported');
      }

      // Send CLS on page unload
      window.addEventListener('beforeunload', () => {
        if (window.gtag && clsValue > 0) {
          window.gtag('event', 'web_vitals', {
            event_category: 'Performance',
            event_label: 'CLS',
            value: Math.round(clsValue * 1000)
          });
        }
      });
    };

    // Security Monitoring
    const initializeSecurityMonitoring = () => {
      // CSP violation reporting
      document.addEventListener('securitypolicyviolation', (e) => {
        console.error('CSP Violation:', e.violatedDirective, e.blockedURI);
        if (window.gtag) {
          window.gtag('event', 'security_violation', {
            event_category: 'Security',
            event_label: e.violatedDirective,
            value: e.blockedURI
          });
        }
      });

      // Monitor for suspicious activity
      let rapidClicks = 0;
      document.addEventListener('click', () => {
        rapidClicks++;
        setTimeout(() => rapidClicks--, 1000);
        
        if (rapidClicks > 10) {
          if (window.gtag) {
            window.gtag('event', 'suspicious_activity', {
              event_category: 'Security',
              event_label: 'rapid_clicking',
              value: rapidClicks
            });
          }
        }
      });
    };

    // User Engagement Tracking
    const initializeEngagementTracking = () => {
      let engagementTime = 0;
      let isEngaged = true;
      
      const trackEngagement = () => {
        if (isEngaged) {
          engagementTime += 1;
          if (engagementTime % 30 === 0 && window.gtag) {
            window.gtag('event', 'user_engagement', {
              event_category: 'Engagement',
              event_label: 'time_spent',
              value: engagementTime
            });
          }
        }
      };

      setInterval(trackEngagement, 1000);

      // Track engagement based on visibility
      document.addEventListener('visibilitychange', () => {
        isEngaged = !document.hidden;
      });

      // Track scroll depth
      let maxScroll = 0;
      window.addEventListener('scroll', () => {
        const scrollPercent = Math.round(
          (window.scrollY / (document.body.scrollHeight - window.innerHeight)) * 100
        );
        
        if (scrollPercent > maxScroll) {
          maxScroll = scrollPercent;
          
          if (scrollPercent >= 25 && scrollPercent < 50 && window.gtag) {
            window.gtag('event', 'scroll_depth', {
              event_category: 'Engagement',
              event_label: '25_percent',
              value: 25
            });
          }
          
          if (scrollPercent >= 50 && scrollPercent < 75 && window.gtag) {
            window.gtag('event', 'scroll_depth', {
              event_category: 'Engagement', 
              event_label: '50_percent',
              value: 50
            });
          }
          
          if (scrollPercent >= 75 && window.gtag) {
            window.gtag('event', 'scroll_depth', {
              event_category: 'Engagement',
              event_label: '75_percent', 
              value: 75
            });
          }
        }
      });
    };

    // Custom Event Tracking for Security Services
    const initializeCustomTracking = () => {
      // Track service card interactions
      document.addEventListener('click', (e) => {
        const target = e.target as HTMLElement;
        
        if (target.closest('.service-card')) {
          const serviceTitle = target.closest('.service-card')?.querySelector('h3')?.textContent;
          if (window.gtag && serviceTitle) {
            window.gtag('event', 'service_card_click', {
              event_category: 'Services',
              event_label: serviceTitle,
              value: 1
            });
          }
        }
        
        if (target.closest('.btn-hero')) {
          if (window.gtag) {
            window.gtag('event', 'cta_click', {
              event_category: 'Conversion',
              event_label: 'security_assessment',
              value: 1
            });
          }
        }
        
        if (target.closest('.contact-action')) {
          if (window.gtag) {
            window.gtag('event', 'contact_method_click', {
              event_category: 'Contact',
              event_label: target.textContent || 'unknown',
              value: 1
            });
          }
        }
      });

      // Track form submissions
      document.addEventListener('submit', (e) => {
        const form = e.target as HTMLFormElement;
        if (form.querySelector('input[type="email"]')) {
          if (window.gtag) {
            window.gtag('event', 'form_submission', {
              event_category: 'Conversion',
              event_label: 'contact_form',
              value: 1
            });
          }
        }
      });
    };

    // Initialize all tracking
    initializeGA4();
    initializePerformanceMonitoring();
    initializeSecurityMonitoring();
    initializeEngagementTracking();
    initializeCustomTracking();

    // Cleanup
    return () => {
      // Remove event listeners if needed
    };
  }, []);

  return null; // This component doesn't render anything
};

// Declare gtag for TypeScript
declare global {
  interface Window {
    gtag: (...args: any[]) => void;
    dataLayer: any[];
  }
}

export default Analytics;