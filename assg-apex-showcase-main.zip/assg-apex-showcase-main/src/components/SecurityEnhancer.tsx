import { useEffect } from 'react';

// Security Enhancement Component
const SecurityEnhancer = () => {
  useEffect(() => {
    // Content Security Policy Implementation
    const implementCSP = () => {
      // Add CSP meta tag if not already present
      if (!document.querySelector('meta[http-equiv="Content-Security-Policy"]')) {
        const cspMeta = document.createElement('meta');
        cspMeta.httpEquiv = 'Content-Security-Policy';
        cspMeta.content = `
          default-src 'self';
          script-src 'self' 'unsafe-inline' 'unsafe-eval' https://www.googletagmanager.com https://www.google-analytics.com;
          style-src 'self' 'unsafe-inline' https://fonts.googleapis.com;
          font-src 'self' https://fonts.gstatic.com;
          img-src 'self' data: https:;
          connect-src 'self' https://www.google-analytics.com;
          frame-ancestors 'none';
          base-uri 'self';
          form-action 'self';
        `.replace(/\s+/g, ' ').trim();
        document.head.appendChild(cspMeta);
      }
    };

    // XSS Protection
    const implementXSSProtection = () => {
      // Sanitize user inputs
      const sanitizeInput = (input: string): string => {
        const div = document.createElement('div');
        div.textContent = input;
        return div.innerHTML;
      };

      // Monitor for potential XSS attempts
      const originalCreateElement = document.createElement;
      document.createElement = function(tagName: string) {
        const element = originalCreateElement.call(this, tagName);
        
        // Block potentially dangerous elements
        if (['script', 'iframe', 'object', 'embed'].includes(tagName.toLowerCase())) {
          console.warn(`Potentially dangerous element creation blocked: ${tagName}`);
          if (window.gtag) {
            window.gtag('event', 'xss_attempt_blocked', {
              event_category: 'Security',
              event_label: tagName,
              value: 1
            });
          }
        }
        
        return element;
      };

      // Validate all form inputs
      document.addEventListener('input', (e) => {
        const target = e.target as HTMLInputElement;
        if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA') {
          const suspiciousPatterns = [
            /<script/i,
            /javascript:/i,
            /on\w+\s*=/i,
            /<iframe/i,
            /eval\(/i
          ];
          
          const hasSuspiciousContent = suspiciousPatterns.some(pattern => 
            pattern.test(target.value)
          );
          
          if (hasSuspiciousContent) {
            console.warn('Suspicious input detected:', target.value);
            target.value = sanitizeInput(target.value);
            
            if (window.gtag) {
              window.gtag('event', 'suspicious_input_detected', {
                event_category: 'Security',
                event_label: 'input_sanitized',
                value: 1
              });
            }
          }
        }
      });
    };

    // CSRF Protection
    const implementCSRFProtection = () => {
      // Generate CSRF token
      const generateCSRFToken = (): string => {
        const array = new Uint8Array(32);
        crypto.getRandomValues(array);
        return Array.from(array, byte => byte.toString(16).padStart(2, '0')).join('');
      };

      // Add CSRF token to forms
      const csrfToken = generateCSRFToken();
      sessionStorage.setItem('csrf_token', csrfToken);

      const forms = document.querySelectorAll('form');
      forms.forEach((form) => {
        if (!form.querySelector('input[name="csrf_token"]')) {
          const csrfInput = document.createElement('input');
          csrfInput.type = 'hidden';
          csrfInput.name = 'csrf_token';
          csrfInput.value = csrfToken;
          form.appendChild(csrfInput);
        }
      });
    };

    // Clickjacking Protection
    const implementClickjackingProtection = () => {
      // Ensure the page is not embedded in an iframe
      if (window.top !== window.self) {
        console.warn('Potential clickjacking attempt detected');
        if (window.gtag) {
          window.gtag('event', 'clickjacking_attempt', {
            event_category: 'Security',
            event_label: 'iframe_embedding',
            value: 1
          });
        }
        
        // Break out of iframe
        window.top!.location.href = window.self.location.href;
      }
    };

    // Session Security
    const implementSessionSecurity = () => {
      // Set secure session flags
      const originalSetItem = sessionStorage.setItem;
      sessionStorage.setItem = function(key: string, value: string) {
        // Encrypt sensitive data before storing
        if (key.includes('token') || key.includes('auth') || key.includes('session')) {
          console.log(`Storing sensitive data: ${key}`);
          // In a real implementation, you'd encrypt the value here
        }
        return originalSetItem.call(this, key, value);
      };

      // Monitor for session hijacking attempts
      let lastActivity = Date.now();
      const sessionTimeout = 30 * 60 * 1000; // 30 minutes

      const checkSessionValidity = () => {
        const now = Date.now();
        if (now - lastActivity > sessionTimeout) {
          console.warn('Session timeout detected');
          sessionStorage.clear();
          if (window.gtag) {
            window.gtag('event', 'session_timeout', {
              event_category: 'Security',
              event_label: 'automatic_logout',
              value: Math.round((now - lastActivity) / 1000)
            });
          }
        }
      };

      // Update last activity on user interaction
      ['click', 'keypress', 'scroll', 'mousemove'].forEach(event => {
        document.addEventListener(event, () => {
          lastActivity = Date.now();
        }, { passive: true });
      });

      setInterval(checkSessionValidity, 60000); // Check every minute
    };

    // Bot Detection
    const implementBotDetection = () => {
      let humanLikeActivity = 0;
      let suspiciousActivity = 0;

      // Monitor mouse movements
      document.addEventListener('mousemove', (e) => {
        const movement = Math.abs(e.movementX) + Math.abs(e.movementY);
        if (movement > 0 && movement < 100) {
          humanLikeActivity++;
        } else if (movement > 200) {
          suspiciousActivity++;
        }
      });

      // Monitor typing patterns
      let keyTimes: number[] = [];
      document.addEventListener('keydown', () => {
        const now = Date.now();
        keyTimes.push(now);
        
        if (keyTimes.length > 10) {
          keyTimes = keyTimes.slice(-10);
          
          // Check for robotic typing patterns
          const intervals = keyTimes.slice(1).map((time, index) => time - keyTimes[index]);
          const avgInterval = intervals.reduce((a, b) => a + b, 0) / intervals.length;
          const variance = intervals.reduce((acc, interval) => acc + Math.pow(interval - avgInterval, 2), 0) / intervals.length;
          
          if (variance < 100) { // Very consistent typing - potentially a bot
            suspiciousActivity++;
          } else {
            humanLikeActivity++;
          }
        }
      });

      // Evaluate bot likelihood periodically
      setInterval(() => {
        const totalActivity = humanLikeActivity + suspiciousActivity;
        if (totalActivity > 20) {
          const suspicionRatio = suspiciousActivity / totalActivity;
          
          if (suspicionRatio > 0.7) {
            console.warn('Potential bot activity detected');
            if (window.gtag) {
              window.gtag('event', 'bot_activity_detected', {
                event_category: 'Security',
                event_label: 'suspicious_behavior',
                value: Math.round(suspicionRatio * 100)
              });
            }
          }
          
          // Reset counters
          humanLikeActivity = 0;
          suspiciousActivity = 0;
        }
      }, 30000);
    };

    // Data Protection
    const implementDataProtection = () => {
      // Disable right-click context menu on sensitive elements
      document.addEventListener('contextmenu', (e) => {
        const target = e.target as HTMLElement;
        if (target.classList.contains('sensitive-data') || 
            target.closest('.sensitive-data')) {
          e.preventDefault();
          console.log('Right-click blocked on sensitive data');
        }
      });

      // Disable text selection on sensitive content
      const sensitiveElements = document.querySelectorAll('.sensitive-data');
      sensitiveElements.forEach(element => {
        (element as HTMLElement).style.userSelect = 'none';
        (element as HTMLElement).style.webkitUserSelect = 'none';
      });

      // Disable developer tools detection
      let devtools = {
        open: false,
        orientation: null
      };

      const threshold = 160;
      setInterval(() => {
        if (window.outerHeight - window.innerHeight > threshold || 
            window.outerWidth - window.innerWidth > threshold) {
          if (!devtools.open) {
            devtools.open = true;
            console.warn('Developer tools opened');
            if (window.gtag) {
              window.gtag('event', 'devtools_opened', {
                event_category: 'Security',
                event_label: 'developer_tools',
                value: 1
              });
            }
          }
        } else {
          devtools.open = false;
        }
      }, 500);
    };

    // Initialize all security measures
    implementCSP();
    implementXSSProtection();
    implementCSRFProtection();
    implementClickjackingProtection();
    implementSessionSecurity();
    implementBotDetection();
    implementDataProtection();

    console.log('Security enhancements initialized');

  }, []);

  return null; // This component doesn't render anything
};

export default SecurityEnhancer;