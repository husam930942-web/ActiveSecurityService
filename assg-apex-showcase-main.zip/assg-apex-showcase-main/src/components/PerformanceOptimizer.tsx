import { useEffect } from 'react';

// Performance Optimization Component
const PerformanceOptimizer = () => {
  useEffect(() => {
    // Image Lazy Loading and Optimization
    const optimizeImages = () => {
      const images = document.querySelectorAll('img[data-src]');
      
      if ('IntersectionObserver' in window) {
        const imageObserver = new IntersectionObserver((entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              const img = entry.target as HTMLImageElement;
              img.src = img.dataset.src!;
              img.classList.remove('lazy');
              imageObserver.unobserve(img);
            }
          });
        });

        images.forEach((img) => imageObserver.observe(img));
      } else {
        // Fallback for older browsers
        images.forEach((img) => {
          const image = img as HTMLImageElement;
          image.src = image.dataset.src!;
        });
      }
    };

    // Critical Resource Preloading
    const preloadCriticalResources = () => {
      // Preload critical fonts
      const fontPreload = document.createElement('link');
      fontPreload.rel = 'preload';
      fontPreload.href = 'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap';
      fontPreload.as = 'style';
      fontPreload.crossOrigin = 'anonymous';
      document.head.appendChild(fontPreload);

      // Preload hero image if exists
      const heroImage = document.querySelector('.hero img') as HTMLImageElement;
      if (heroImage && heroImage.src) {
        const imagePreload = document.createElement('link');
        imagePreload.rel = 'preload';
        imagePreload.href = heroImage.src;
        imagePreload.as = 'image';
        document.head.appendChild(imagePreload);
      }
    };

    // Service Worker Registration for Caching
    const registerServiceWorker = async () => {
      if ('serviceWorker' in navigator) {
        try {
          const registration = await navigator.serviceWorker.register('/sw.js');
          console.log('Service Worker registered:', registration);
        } catch (error) {
          console.log('Service Worker registration failed:', error);
        }
      }
    };

    // Critical CSS Inlining Detection
    const optimizeCSSLoading = () => {
      // Detect if critical CSS is inlined
      const criticalCSS = document.querySelector('style[data-critical]');
      if (!criticalCSS) {
        // Add critical CSS inline for faster initial render
        const style = document.createElement('style');
        style.setAttribute('data-critical', 'true');
        style.textContent = `
          .glass-card { backdrop-filter: blur(12px); }
          .btn-hero { background: linear-gradient(135deg, #3b82f6, #60a5fa); }
          .text-hero { background: linear-gradient(135deg, #f8fafc, #60a5fa); -webkit-background-clip: text; }
        `;
        document.head.appendChild(style);
      }
    };

    // Bundle Splitting Detection
    const monitorBundlePerformance = () => {
      // Monitor script loading times
      const scripts = document.querySelectorAll('script[src]');
      scripts.forEach((script) => {
        const scriptElement = script as HTMLScriptElement;
        const startTime = performance.now();
        
        scriptElement.addEventListener('load', () => {
          const loadTime = performance.now() - startTime;
          console.log(`Script ${scriptElement.src} loaded in ${loadTime}ms`);
          
          // Send to analytics if available
          if (window.gtag) {
            window.gtag('event', 'script_load_time', {
              event_category: 'Performance',
              event_label: scriptElement.src,
              value: Math.round(loadTime)
            });
          }
        });
      });
    };

    // Memory Usage Monitoring
    const monitorMemoryUsage = () => {
      if ('memory' in performance) {
        const memoryInfo = (performance as any).memory;
        const memoryUsage = {
          used: Math.round(memoryInfo.usedJSHeapSize / 1048576), // MB
          total: Math.round(memoryInfo.totalJSHeapSize / 1048576), // MB
          limit: Math.round(memoryInfo.jsHeapSizeLimit / 1048576) // MB
        };
        
        console.log('Memory Usage:', memoryUsage);
        
        // Alert if memory usage is high
        if (memoryUsage.used > memoryUsage.limit * 0.8) {
          console.warn('High memory usage detected');
          if (window.gtag) {
            window.gtag('event', 'high_memory_usage', {
              event_category: 'Performance',
              event_label: 'memory_warning',
              value: memoryUsage.used
            });
          }
        }
      }
    };

    // Network Quality Detection
    const detectNetworkQuality = () => {
      if ('connection' in navigator) {
        const connection = (navigator as any).connection;
        const networkInfo = {
          effectiveType: connection.effectiveType,
          downlink: connection.downlink,
          rtt: connection.rtt
        };
        
        console.log('Network Info:', networkInfo);
        
        // Adjust image quality based on connection
        if (connection.effectiveType === 'slow-2g' || connection.effectiveType === '2g') {
          document.documentElement.classList.add('low-bandwidth');
        }
        
        if (window.gtag) {
          window.gtag('event', 'network_quality', {
            event_category: 'Performance',
            event_label: connection.effectiveType,
            value: Math.round(connection.downlink)
          });
        }
      }
    };

    // Resource Hints for Better Performance
    const addResourceHints = () => {
      // DNS prefetch for external domains
      const dnsPrefetches = [
        'fonts.googleapis.com',
        'fonts.gstatic.com',
        'www.google-analytics.com'
      ];
      
      dnsPrefetches.forEach((domain) => {
        const link = document.createElement('link');
        link.rel = 'dns-prefetch';
        link.href = `//${domain}`;
        document.head.appendChild(link);
      });

      // Preconnect to critical origins
      const preconnects = [
        'https://fonts.googleapis.com',
        'https://fonts.gstatic.com'
      ];
      
      preconnects.forEach((origin) => {
        const link = document.createElement('link');
        link.rel = 'preconnect';
        link.href = origin;
        link.crossOrigin = 'anonymous';
        document.head.appendChild(link);
      });
    };

    // Initialize all optimizations
    optimizeImages();
    preloadCriticalResources();
    registerServiceWorker();
    optimizeCSSLoading();
    monitorBundlePerformance();
    detectNetworkQuality();
    addResourceHints();
    
    // Monitor memory usage every 30 seconds
    const memoryInterval = setInterval(monitorMemoryUsage, 30000);

    // Cleanup
    return () => {
      clearInterval(memoryInterval);
    };
  }, []);

  return null; // This component doesn't render anything
};

export default PerformanceOptimizer;