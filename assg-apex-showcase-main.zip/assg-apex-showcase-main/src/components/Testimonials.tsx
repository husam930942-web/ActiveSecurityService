import { useState, useEffect } from 'react';

const Testimonials = () => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const testimonials = [
    {
      name: "Sarah Chen",
      position: "Chief Security Officer",
      company: "TechCorp Industries",
      avatar: "https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg?auto=compress&cs=tinysrgb&w=400",
      content: "ASSG transformed our security infrastructure completely. Their proactive approach and cutting-edge technology have given us peace of mind while allowing our business to scale confidently. The ROI has been exceptional.",
      rating: 5
    },
    {
      name: "Michael Rodriguez",
      position: "CEO",
      company: "Global Finance Group",
      avatar: "https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=400",
      content: "The level of professionalism and expertise from ASSG is unmatched. Their executive protection services are discreet yet comprehensive. We've never felt more secure during high-stakes business operations.",
      rating: 5
    },
    {
      name: "Dr. Amanda Foster",
      position: "Director of Operations",
      company: "MedTech Solutions",
      avatar: "https://images.pexels.com/photos/1181690/pexels-photo-1181690.jpeg?auto=compress&cs=tinysrgb&w=400",
      content: "ASSG's integrated approach to physical and cyber security is exactly what our healthcare organization needed. Their compliance expertise and 24/7 monitoring have been game-changing for our operations.",
      rating: 5
    },
    {
      name: "James Park",
      position: "VP of Security",
      company: "Retail Dynamics",
      avatar: "https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg?auto=compress&cs=tinysrgb&w=400",
      content: "The AI-powered surveillance system ASSG implemented across our retail locations has reduced incidents by 85%. Their team's response time and attention to detail consistently exceed our expectations.",
      rating: 5
    }
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIndex((prevIndex) => (prevIndex + 1) % testimonials.length);
    }, 5000);

    return () => clearInterval(timer);
  }, [testimonials.length]);

  const nextTestimonial = () => {
    setCurrentIndex((prevIndex) => (prevIndex + 1) % testimonials.length);
  };

  const prevTestimonial = () => {
    setCurrentIndex((prevIndex) => (prevIndex - 1 + testimonials.length) % testimonials.length);
  };

  return (
    <section id="testimonials" className="py-24 px-6">
      <div className="container mx-auto">
        <div className="text-center mb-16 animate-slide-up">
          <h2 className="text-5xl font-bold mb-6 text-hero">
            Trusted by Industry Leaders
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Don't just take our word for it. See how ASSG has transformed security 
            operations for organizations across diverse industries.
          </p>
        </div>

        {/* Main Testimonial */}
        <div className="max-w-5xl mx-auto">
          <div className="testimonial-card relative overflow-hidden">
            <div className="flex items-start space-x-6">
              {/* Avatar */}
              <div className="flex-shrink-0">
                <img 
                  src={testimonials[currentIndex].avatar}
                  alt={testimonials[currentIndex].name}
                  className="w-20 h-20 rounded-2xl object-cover border-2 border-primary/20"
                />
              </div>

              {/* Content */}
              <div className="flex-1">
                {/* Rating */}
                <div className="flex items-center space-x-1 mb-4">
                  {[...Array(testimonials[currentIndex].rating)].map((_, i) => (
                    <svg key={i} className="w-5 h-5 text-primary" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M12,17.27L18.18,21L16.54,13.97L22,9.24L14.81,8.62L12,2L9.19,8.62L2,9.24L7.46,13.97L5.82,21L12,17.27Z"/>
                    </svg>
                  ))}
                </div>

                {/* Quote */}
                <blockquote className="text-xl text-foreground mb-6 leading-relaxed">
                  "{testimonials[currentIndex].content}"
                </blockquote>

                {/* Attribution */}
                <div>
                  <div className="font-bold text-lg text-foreground">
                    {testimonials[currentIndex].name}
                  </div>
                  <div className="text-primary font-medium">
                    {testimonials[currentIndex].position}
                  </div>
                  <div className="text-muted-foreground">
                    {testimonials[currentIndex].company}
                  </div>
                </div>
              </div>

              {/* Quote Icon */}
              <div className="text-primary/20 text-6xl leading-none">
                <svg className="w-16 h-16" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M14,17H17L19,13V7H13V13H16M6,17H9L11,13V7H5V13H8L6,17Z"/>
                </svg>
              </div>
            </div>
          </div>

          {/* Navigation */}
          <div className="flex justify-center items-center mt-8 space-x-6">
            {/* Previous Button */}
            <button
              onClick={prevTestimonial}
              className="p-3 rounded-full glass-card hover:bg-primary/10 transition-colors duration-300"
            >
              <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
              </svg>
            </button>

            {/* Dots Indicator */}
            <div className="flex space-x-2">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentIndex(index)}
                  className={`w-3 h-3 rounded-full transition-all duration-300 ${
                    index === currentIndex 
                      ? 'bg-primary w-8' 
                      : 'bg-muted-foreground/30 hover:bg-primary/50'
                  }`}
                />
              ))}
            </div>

            {/* Next Button */}
            <button
              onClick={nextTestimonial}
              className="p-3 rounded-full glass-card hover:bg-primary/10 transition-colors duration-300"
            >
              <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </button>
          </div>
        </div>

        {/* Trust Logos */}
        <div className="mt-16 text-center">
          <p className="text-muted-foreground mb-8">Protecting leading organizations across industries</p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 opacity-50">
            <div className="glass-card p-6 rounded-xl flex items-center justify-center">
              <span className="font-bold text-lg text-muted-foreground">ENTERPRISE</span>
            </div>
            <div className="glass-card p-6 rounded-xl flex items-center justify-center">
              <span className="font-bold text-lg text-muted-foreground">FINTECH</span>
            </div>
            <div className="glass-card p-6 rounded-xl flex items-center justify-center">
              <span className="font-bold text-lg text-muted-foreground">HEALTHCARE</span>
            </div>
            <div className="glass-card p-6 rounded-xl flex items-center justify-center">
              <span className="font-bold text-lg text-muted-foreground">RETAIL</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;