import { useState, useEffect, useRef } from 'react';
import { Shield, Camera, Users, Lock, AlertTriangle, Car } from 'lucide-react';
import ServiceDetails from './ServiceDetails';

const Services = () => {
  const [selectedService, setSelectedService] = useState<any>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const services = [
    {
      icon: (
        <svg className="w-12 h-12" fill="currentColor" viewBox="0 0 24 24">
          <path d="M12,2A2,2 0 0,1 14,4A2,2 0 0,1 12,6A2,2 0 0,1 10,4A2,2 0 0,1 12,2M21,9V7L15,1V3H9V1L3,7V9H1V11H3L4,17V21H6V17H18V21H20V17L21,11H23V9H21Z"/>
        </svg>
      ),
      title: "Valet Parking",
      description: "Professional valet parking services for events, hotels, restaurants, and corporate facilities with trained personnel.",
      details: "Our valet parking service provides professional, courteous, and efficient parking solutions for your guests and customers. We ensure their vehicles are handled with the utmost care and security.",
      features: [
        "Uniformed and trained valet attendants",
        "Insurance coverage for all vehicles",
        "Advanced vehicle tracking system",
        "24/7 vehicle security monitoring",
        "Weather protection for vehicles",
        "Express service for VIP guests",
        "Multilingual staff available",
        "Real-time parking availability updates"
      ],
      process: [
        "Initial site assessment and capacity planning",
        "Staff training and uniform provision",
        "Setup of valet stations and security perimeter",
        "Implementation of vehicle tracking system",
        "24/7 monitoring and customer service",
        "Regular quality control and reporting"
      ]
    },
    {
      icon: (
        <svg className="w-12 h-12" fill="currentColor" viewBox="0 0 24 24">
          <path d="M12,2A2,2 0 0,1 14,4C14,5.11 13.1,6 12,6C10.89,6 10,5.1 10,4A2,2 0 0,1 12,2M21,9V7L15,1V3H9V1L3,7V9H1V11H3L4,17V21H6V17H18V21H20V17L21,11H23V9H21M7.5,12A1.5,1.5 0 0,1 9,10.5A1.5,1.5 0 0,1 10.5,12A1.5,1.5 0 0,1 9,13.5A1.5,1.5 0 0,1 7.5,12M16.5,12A1.5,1.5 0 0,1 18,10.5A1.5,1.5 0 0,1 19.5,12A1.5,1.5 0 0,1 18,13.5A1.5,1.5 0 0,1 16.5,12Z"/>
        </svg>
      ),
      title: "Bouncer Services",
      description: "Professional crowd control and door security for nightclubs, bars, events, and entertainment venues.",
      details: "Our bouncer services provide professional crowd management and venue security to ensure a safe and enjoyable environment for your patrons while protecting your business interests.",
      features: [
        "Licensed and trained security personnel",
        "Crowd control and queue management", 
        "ID verification and age checking",
        "Conflict de-escalation techniques",
        "Emergency response protocols",
        "VIP guest escort services",
        "Incident documentation and reporting",
        "Coordination with local law enforcement"
      ],
      process: [
        "Venue security assessment and planning",
        "Staff selection based on venue requirements",
        "Specialized training for venue type",
        "Setup of security protocols and procedures",
        "Active monitoring and crowd management",
        "Continuous safety evaluation and reporting"
      ]
    },
    {
      icon: (
        <svg className="w-12 h-12" fill="currentColor" viewBox="0 0 24 24">
          <path d="M12,2C13.1,2 14,2.9 14,4C14,5.1 13.1,6 12,6C10.9,6 10,5.1 10,4C10,2.9 10.9,2 12,2M21,9V7L15,1V3H9V1L3,7V9H1V11H3L4,17V21H6V17H18V21H20V17L21,11H23V9H21M12,8L14,14H10L12,8Z"/>
        </svg>
      ),
      title: "Bodyguard Services",
      description: "Elite personal protection for executives, celebrities, and high-profile individuals with specialized training.",
      details: "Our bodyguard services provide discrete, professional personal protection tailored to individual threat levels and lifestyle requirements. Our agents are trained in advanced security techniques and emergency response.",
      features: [
        "Highly trained personal protection officers",
        "Threat assessment and risk analysis",
        "Advanced driving and evasion techniques",
        "Discrete surveillance detection",
        "Emergency medical response training",
        "Secure transportation coordination",
        "24/7 availability and communication",
        "Coordination with security agencies"
      ],
      process: [
        "Comprehensive threat and risk assessment",
        "Personal security plan development",
        "Agent selection and briefing",
        "Security route planning and reconnaissance",
        "Active protection deployment",
        "Continuous threat monitoring and adaptation"
      ]
    },
    {
      icon: (
        <svg className="w-12 h-12" fill="currentColor" viewBox="0 0 24 24">
          <path d="M19,3H5A2,2 0 0,0 3,5V19A2,2 0 0,0 5,21H19A2,2 0 0,0 21,19V5A2,2 0 0,0 19,3M19,19H5V5H19V19M17,8.5L12,6L7,8.5V7L12,4.5L17,7V8.5M17,17H7V9H17V17Z"/>
        </svg>
      ),
      title: "Housekeeper Services",
      description: "Trusted residential cleaning and maintenance services with background-verified staff for homes and estates.",
      details: "Our housekeeper services provide reliable, trustworthy cleaning and maintenance for residential properties. All staff undergo thorough background checks and are bonded and insured for your peace of mind.",
      features: [
        "Background-verified cleaning staff",
        "Comprehensive cleaning protocols",
        "Flexible scheduling options",
        "Eco-friendly cleaning products available",
        "Key management and security protocols",
        "Regular quality inspections", 
        "Bonded and insured personnel",
        "Special event cleaning services"
      ],
      process: [
        "Property assessment and service customization",
        "Staff assignment and security clearance",
        "Cleaning protocol establishment",
        "Key management and access setup",
        "Regular service delivery and monitoring",
        "Quality control and client feedback"
      ]
    },
    {
      icon: (
        <svg className="w-12 h-12" fill="currentColor" viewBox="0 0 24 24">
          <path d="M12,17A2,2 0 0,0 14,15C14,13.89 13.1,13 12,13A2,2 0 0,0 10,15A2,2 0 0,0 12,17M18,8A2,2 0 0,1 20,10V20A2,2 0 0,1 18,22H6A2,2 0 0,1 4,20V10C4,8.89 4.9,8 6,8H7V6A5,5 0 0,1 12,1A5,5 0 0,1 17,6V8H18M12,3A3,3 0 0,0 9,6V8H15V6A3,3 0 0,0 12,3Z"/>
        </svg>
      ),
      title: "Security Guard Services",
      description: "Professional security personnel for facilities, events, and asset protection with comprehensive training.",
      details: "Our security guard services provide professional protection for your facilities, assets, and personnel. Our guards are licensed, trained, and equipped to handle various security situations with professionalism and expertise.",
      features: [
        "Licensed security officers",
        "Advanced training in security protocols",
        "Access control and visitor management",
        "Patrol services and surveillance",
        "Incident response and documentation", 
        "Emergency procedures and first aid",
        "Technology integration capabilities",
        "Regular reporting and communication"
      ],
      process: [
        "Security needs assessment and planning",
        "Officer selection and assignment",
        "Site-specific training and orientation",
        "Security protocol implementation",
        "Active monitoring and patrol services",
        "Regular performance evaluation and reporting"
      ]
    },
    {
      icon: (
        <svg className="w-12 h-12" fill="currentColor" viewBox="0 0 24 24">
          <path d="M17,9H7V7A5,5 0 0,1 12,2A5,5 0 0,1 17,7V9M12,17A2,2 0 0,0 14,15C14,13.89 13.1,13 12,13A2,2 0 0,0 10,15A2,2 0 0,0 12,17M18,8A2,2 0 0,1 20,10V20A2,2 0 0,1 18,22H6A2,2 0 0,1 4,20V10C4,8.89 4.9,8 6,8H7V6A5,5 0 0,1 12,1A5,5 0 0,1 17,6V8H18M12,3A3,3 0 0,0 9,6V8H15V6A3,3 0 0,0 12,3Z"/>
        </svg>
      ),
      title: "Surveillance & Monitoring",
      description: "AI-powered video analytics with 4K resolution, facial recognition, and intelligent threat detection capabilities.",
      details: "Our surveillance and monitoring services utilize cutting-edge technology to provide comprehensive security coverage. We deploy advanced camera systems with AI analytics to detect and respond to potential threats in real-time.",
      features: [
        "4K high-resolution camera systems",
        "AI-powered video analytics",
        "Facial recognition technology",
        "Motion detection and alerts",
        "24/7 monitoring centers",
        "Cloud storage and backup",
        "Mobile app access and notifications",
        "Integration with existing security systems"
      ],
      process: [
        "Site survey and system design",
        "Professional installation and setup",
        "System configuration and testing",
        "Staff training and handover",
        "24/7 monitoring activation",
        "Regular maintenance and updates"
      ]
    }
  ];

  const handleLearnMore = (service: any) => {
    setSelectedService(service);
    setIsDialogOpen(true);
  };

  return (
    <section id="services" className="py-24 px-6">
      <div className="container mx-auto">
        <div className="text-center mb-16 animate-slide-up">
          <h2 className="text-5xl font-bold mb-6 text-hero">
            Elite Security Services
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Comprehensive security solutions designed for enterprise-level protection. 
            Each service is tailored to your specific risk profile and operational requirements.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div 
              key={index} 
              className="service-card group animate-slide-up"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="text-primary mb-6 group-hover:scale-110 transition-transform duration-500">
                {service.icon}
              </div>
              
              <h3 className="text-2xl font-bold mb-4 text-foreground">
                {service.title}
              </h3>
              
              <p className="text-muted-foreground leading-relaxed">
                {service.description}
              </p>

              <div className="mt-6 pt-6 border-t border-white/10">
                <button 
                  onClick={() => handleLearnMore(service)}
                  className="text-primary hover:text-primary-glow transition-colors duration-300 font-medium"
                >
                  Learn More →
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Call to Action */}
        <div className="text-center mt-16">
          <div className="glass-card p-12 rounded-3xl max-w-4xl mx-auto">
            <h3 className="text-3xl font-bold mb-4 text-hero">
              Need a Custom Security Solution?
            </h3>
            <p className="text-lg text-muted-foreground mb-8">
              Our security experts will design a tailored protection strategy for your unique requirements.
            </p>
            <button 
              className="btn-hero text-lg px-8 py-4"
              onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
            >
              Schedule Consultation
            </button>
          </div>
        </div>
      </div>

      <ServiceDetails 
        isOpen={isDialogOpen}
        onClose={() => setIsDialogOpen(false)}
        service={selectedService}
      />
    </section>
  );
};

export default Services;