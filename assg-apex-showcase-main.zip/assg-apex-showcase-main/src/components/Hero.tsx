import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Shield, Lock, Eye, Users } from 'lucide-react';
import assgLogo from '@/assets/assg-logo.png';

const Hero = () => {
  const [scrollY, setScrollY] = useState(0);
  const [isVisible, setIsVisible] = useState(false);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY });
    };
    
    window.addEventListener('scroll', handleScroll);
    window.addEventListener('mousemove', handleMouseMove);
    
    // Trigger entrance animation
    const timer = setTimeout(() => setIsVisible(true), 100);
    
    return () => {
      window.removeEventListener('scroll', handleScroll);
      window.removeEventListener('mousemove', handleMouseMove);
      clearTimeout(timer);
    };
  }, []);

  return (
    <section className="parallax-hero relative overflow-hidden">
      {/* Advanced Parallax Background Layers */}
      <div 
        className="parallax-layer opacity-20"
        style={{ transform: `translateY(${scrollY * 0.3}px)` }}
      >
        <div className="absolute inset-0 bg-gradient-to-br from-primary/20 via-transparent to-accent/10" />
      </div>
      
      {/* Interactive Mouse Follower */}
      <div 
        className="absolute w-96 h-96 bg-primary/5 rounded-full blur-3xl transition-transform duration-300 ease-out pointer-events-none"
        style={{ 
          left: mousePosition.x - 192, 
          top: mousePosition.y - 192,
          transform: `scale(${isVisible ? 1 : 0})` 
        }}
      />

      {/* Animated Security Grid Background */}
      <div className="absolute inset-0 opacity-5">
        <div className="grid grid-cols-12 grid-rows-8 h-full w-full">
          {Array.from({ length: 96 }).map((_, i) => (
            <div 
              key={i}
              className="border border-primary/20 animate-pulse"
              style={{ animationDelay: `${i * 0.05}s` }}
            />
          ))}
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-6 text-center z-10 relative pt-20">
        <div className={`transition-all duration-1000 ease-out ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0'}`}>
          {/* Enhanced Logo/Brand */}
          <div className="mb-8">
            <div className="inline-flex items-center justify-center w-32 h-32 rounded-2xl glass-card mb-6 p-4 shadow-2xl hover:scale-110 hover:shadow-primary/20 transition-all duration-500 group">
              <img 
                src={assgLogo} 
                alt="Active Security Services Group - Elite Corporate Security Solutions" 
                className="w-full h-full object-contain group-hover:brightness-110 transition-all duration-300"
                loading="eager"
              />
              <div className="absolute inset-0 rounded-2xl bg-gradient-to-tr from-primary/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
            </div>
          </div>

          {/* Enhanced Hero Text with Staggered Animation */}
          <div className={`transition-all duration-1000 delay-300 ease-out ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'}`}>
            <h1 className="text-6xl md:text-8xl font-bold mb-6 text-hero leading-tight">
              <span className="inline-block hover:scale-105 transition-transform duration-300">Active</span>{' '}
              <span className="inline-block hover:scale-105 transition-transform duration-300 delay-75">Security</span>
              <br />
              <span className="text-glow inline-block hover:scale-105 transition-transform duration-300 delay-150">Services</span>{' '}
              <span className="text-glow inline-block hover:scale-105 transition-transform duration-300 delay-225">Group</span>
            </h1>
          </div>
          
          <div className={`transition-all duration-1000 delay-500 ease-out ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'}`}>
            <p className="text-xl md:text-2xl text-muted-foreground mb-12 max-w-3xl mx-auto leading-relaxed">
              Elite corporate security solutions for the world's most demanding enterprises. 
              Protecting what matters most with cutting-edge technology and unmatched expertise.
            </p>
          </div>

          {/* Enhanced CTA Buttons with Advanced Animations */}
          <div className={`flex flex-col sm:flex-row gap-6 justify-center items-center transition-all duration-1000 delay-700 ease-out ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'}`}>
            <Button 
              className="btn-hero text-lg px-10 py-6 group relative overflow-hidden"
              onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
            >
              <Shield className="w-5 h-5 mr-2 group-hover:rotate-12 transition-transform duration-300" />
              <span className="relative z-10">Get Security Assessment</span>
              <div className="absolute inset-0 bg-gradient-to-r from-primary/0 via-primary-glow/50 to-primary/0 transform -translate-x-full group-hover:translate-x-full transition-transform duration-700 ease-in-out" />
            </Button>
            
            <Button 
              variant="outline" 
              className="btn-glass text-lg px-8 py-6 group relative overflow-hidden"
              onClick={() => document.getElementById('services')?.scrollIntoView({ behavior: 'smooth' })}
            >
              <Eye className="w-5 h-5 mr-2 group-hover:scale-110 transition-transform duration-300" />
              <span className="relative z-10">Our Services</span>
              <div className="absolute inset-0 bg-primary/10 transform scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-left" />
            </Button>
          </div>

          {/* Enhanced Trust Indicators with Counter Animation */}
          <div className={`mt-16 grid grid-cols-2 md:grid-cols-4 gap-8 text-center transition-all duration-1000 delay-900 ease-out ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'}`}>
            <div className="glass-card p-4 rounded-xl hover:scale-105 hover:shadow-xl transition-all duration-300 group">
              <Shield className="w-6 h-6 mx-auto mb-2 text-primary group-hover:animate-pulse" />
              <div className="text-2xl font-bold text-primary mb-1 counter" data-target="100">100+</div>
              <div className="text-sm text-muted-foreground">Clients Protected</div>
            </div>
            <div className="glass-card p-4 rounded-xl hover:scale-105 hover:shadow-xl transition-all duration-300 group">
              <Lock className="w-6 h-6 mx-auto mb-2 text-primary group-hover:animate-pulse" />
              <div className="text-2xl font-bold text-primary mb-1">24/7</div>
              <div className="text-sm text-muted-foreground">Global Monitoring</div>
            </div>
            <div className="glass-card p-4 rounded-xl hover:scale-105 hover:shadow-xl transition-all duration-300 group">
              <Eye className="w-6 h-6 mx-auto mb-2 text-primary group-hover:animate-pulse" />
              <div className="text-2xl font-bold text-primary mb-1">99.9%</div>
              <div className="text-sm text-muted-foreground">Uptime Guarantee</div>
            </div>
            <div className="glass-card p-4 rounded-xl hover:scale-105 hover:shadow-xl transition-all duration-300 group">
              <Users className="w-6 h-6 mx-auto mb-2 text-primary group-hover:animate-pulse" />
              <div className="text-2xl font-bold text-primary mb-1">4+</div>
              <div className="text-sm text-muted-foreground">Years Experience</div>
            </div>
          </div>
        </div>
      </div>

      {/* Floating Security Elements */}
      <div className="absolute top-1/4 left-10 animate-float opacity-30">
        <div className="w-3 h-3 bg-primary rounded-full animate-glow" />
      </div>
      <div className="absolute top-3/4 right-10 animate-float opacity-30" style={{ animationDelay: '2s' }}>
        <div className="w-2 h-2 bg-accent rounded-full animate-glow" />
      </div>
      <div className="absolute bottom-1/4 left-1/4 animate-float opacity-30" style={{ animationDelay: '4s' }}>
        <div className="w-4 h-4 bg-primary-glow rounded-full animate-glow" />
      </div>
    </section>
  );
};

export default Hero;