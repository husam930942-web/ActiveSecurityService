import { useEffect, useState, useRef } from 'react';

const About = () => {
  const [inView, setInView] = useState(false);
  const [counts, setCounts] = useState({
    clients: 0,
    years: 0,
    uptime: 0,
    response: 0
  });
  const sectionRef = useRef<HTMLDivElement>(null);

  const finalCounts = {
    clients: 100,
    years: 4,
    uptime: 99,
    response: 2
  };

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setInView(true);
        }
      },
      { threshold: 0.3 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (inView) {
      const duration = 2000; // 2 seconds
      const steps = 60;
      const increment = duration / steps;

      Object.keys(finalCounts).forEach((key) => {
        const finalValue = finalCounts[key as keyof typeof finalCounts];
        let currentValue = 0;
        const step = finalValue / steps;

        const timer = setInterval(() => {
          currentValue += step;
          if (currentValue >= finalValue) {
            currentValue = finalValue;
            clearInterval(timer);
          }
          
          setCounts(prev => ({
            ...prev,
            [key]: Math.floor(currentValue)
          }));
        }, increment);
      });
    }
  }, [inView]);

  return (
    <section id="about" className="py-24 px-6" ref={sectionRef}>
      <div className="container mx-auto">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Content Side */}
          <div className="animate-slide-up">
            <h2 className="text-5xl font-bold mb-8 text-hero">
              Trusted by Industry Leaders
            </h2>
            
            <div className="space-y-6 text-lg text-muted-foreground leading-relaxed">
              <p>
                <strong className="text-foreground">Active Security Services Group (ASSG)</strong> has been at the forefront 
                of enterprise security solutions for over a decade. We protect Fortune 500 companies, 
                government agencies, and high-profile individuals with cutting-edge technology and 
                uncompromising professionalism.
              </p>
              
              <p>
                Our team of certified security professionals combines military-grade protocols 
                with innovative technology solutions. From advanced surveillance systems to 
                executive protection services, we deliver security that adapts to evolving threats.
              </p>
              
              <p>
                Every client receives a customized security strategy designed to address their 
                specific risk profile, operational requirements, and compliance standards. 
                Our proactive approach ensures threats are neutralized before they impact your business.
              </p>
            </div>

            {/* Key Features */}
            <div className="mt-12 grid grid-cols-2 gap-6">
              <div className="glass-card p-6 rounded-2xl">
                <div className="text-primary mb-3">
                  <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M9,22A1,1 0 0,1 8,21V18H4A2,2 0 0,1 2,16V4C2,2.89 2.9,2 4,2H20A2,2 0 0,1 22,4V16A2,2 0 0,1 20,18H13.9L10.2,21.71C10,21.9 9.75,22 9.5,22V22H9M10,16V19.08L13.08,16H20V4H4V16H10Z"/>
                  </svg>
                </div>
                <h3 className="font-bold text-foreground mb-2">24/7 Support</h3>
                <p className="text-sm text-muted-foreground">Round-the-clock monitoring and rapid response capabilities</p>
              </div>
              
              <div className="glass-card p-6 rounded-2xl">
                <div className="text-primary mb-3">
                  <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12,1L3,5V11C3,16.55 6.84,21.74 12,23C17.16,21.74 21,16.55 21,11V5L12,1M12,7C13.4,7 14.8,8.6 14.8,10.5V11.5C14.8,12.4 14.4,13.2 13.7,13.7L12.9,14.2C12.4,14.5 12,15.1 12,15.8V17H11V15.8C11,14.6 11.6,13.5 12.6,12.9L13.4,12.4C13.7,12.2 13.8,11.9 13.8,11.5V10.5C13.8,9.1 12.9,8 12,8S10.2,9.1 10.2,10.5H9.2C9.2,8.6 10.6,7 12,7M11.5,18.5C11.5,19.3 12.2,20 13,20S14.5,19.3 14.5,18.5 13.8,17 13,17 11.5,17.7 11.5,18.5Z"/>
                  </svg>
                </div>
                <h3 className="font-bold text-foreground mb-2">Certified Team</h3>
                <p className="text-sm text-muted-foreground">Military and law enforcement background with ongoing training</p>
              </div>
            </div>
          </div>

          {/* Stats Side */}
          <div className="space-y-8">
            <div className="glass-card p-12 rounded-3xl text-center">
              <div className="counter text-6xl font-bold text-primary mb-2">
                {counts.clients}+
              </div>
              <div className="text-xl font-medium text-foreground mb-2">Clients Protected</div>
              <div className="text-muted-foreground">Enterprise organizations trust our security solutions</div>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div className="glass-card p-6 rounded-2xl text-center">
                <div className="counter text-3xl font-bold text-primary mb-1">
                  {counts.years}+
                </div>
                <div className="text-sm font-medium text-foreground mb-1">Years</div>
                <div className="text-xs text-muted-foreground">Experience</div>
              </div>
              <div className="glass-card p-6 rounded-2xl text-center">
                <div className="counter text-3xl font-bold text-primary mb-1">
                  {counts.uptime}.9%
                </div>
                <div className="text-sm font-medium text-foreground mb-1">Uptime</div>
                <div className="text-xs text-muted-foreground">Guarantee</div>
              </div>
              
              <div className="glass-card p-6 rounded-2xl text-center">
                <div className="counter text-3xl font-bold text-primary mb-1">
                  &lt;{counts.response}min
                </div>
                <div className="text-sm font-medium text-foreground mb-1">Response</div>
                <div className="text-xs text-muted-foreground">Time</div>
              </div>
            </div>

          </div>
        </div>
      </div>
    </section>
  );
};

export default About;